const apiConfig={DOMAIN_URL:process.env.DOMAIN_URL||""};export default apiConfig;
